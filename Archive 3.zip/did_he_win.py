def did_he_win(table, player_id):

    # horizontal
    for raw in range(0, table.shape[0]):
        num_of_consecutive = 0
        for column in range(0, table.shape[1]):
            if table[raw, column] == player_id:
                num_of_consecutive += 1
            else:
                num_of_consecutive = 0
            if num_of_consecutive == 4:
                return 1

    # vertical
    for column in range(0, table.shape[1]):
        num_of_consecutive = 0
        for raw in range(0, table.shape[0]):
            if table[raw, column] == player_id:
                num_of_consecutive += 1
            else:
                num_of_consecutive = 0
            if num_of_consecutive == 4:
                return 1

    # ascending diagonal
    for diagonal_num in range(1, table.shape[0] + table.shape[1]-1):
        if diagonal_num <= table.shape[0]:
            raw = diagonal_num-1
            column = 0
        else:
            raw = table.shape[0] - 1
            column = diagonal_num - table.shape[0]
        num_of_consecutive = 0
        while raw > 0 and column < table.shape[1]:
            if table[raw, column] == player_id:
                num_of_consecutive += 1
            else:
                num_of_consecutive = 0
            if num_of_consecutive == 4:
                return 1
            raw -= 1
            column += 1

    # descending diagonal
    for diagonal_num in range(1, table.shape[0] + table.shape[1]-1):
        if diagonal_num <= table.shape[0]:
            raw = table.shape[0] - diagonal_num
            column = 0
        else:
            raw = 0
            column = diagonal_num - table.shape[0]
        num_of_consecutive = 0
        while raw < table.shape[0] and column < table.shape[1]:
            if table[raw, column] == player_id:
                num_of_consecutive += 1
            else:
                num_of_consecutive = 0
            if num_of_consecutive == 4:
                return 1
            raw += 1
            column += 1

    return 0
