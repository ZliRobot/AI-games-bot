import numpy as np
import matplotlib.pyplot as plt
import time
import subprocess
import did_he_win as dhw


# transform matrix to string to communicate with bot like engine 
def mat2str(board):
    a = board
    s = repr(a).replace('array', '')
    s = s.replace(']]', '')
    s = s.replace('],', ';')
    s = ''.join([c for c in s if c not in ('(', ')', '[', ']', '\n', ' ')])
    return s


# communicate with bot to play move
def player_play(player_id, i_round, board, t_move):
    if player_id == 1:
        player = player1
    else:
        player = player2

    player.stdin.write("update game round %i\n" % i_round)
    player.stdin.write("update game field %s\n" % mat2str(board))
    player.stdin.write("action move %i\n" % t_move)
    return player.stdout.readline()


# starting settings, sent at the beginning of game
def start_string(player_id):
    return ("settings timebank 10000\n"
            "settings time_per_move 500\n"
            "settings player_names player1,player2\n"
            "settings your_bot player%c\n"
            "settings your_botid %c\n"
            "settings field_columns 7\n"
            "settings field_rows 6\n" % (str(player_id), str(player_id)))


# updates board after move
def board_update(board, move, player_id):
    if 0 != board[0, int(move.split()[1])]:
        print "test.py: Error - full column"

    red = board.shape[0] - 1

    while board[red, move.split()[1]] != 0:
        red -= 1

    board[red, move.split()[1]] = player_id
    return board


# run bots and open communication
player1 = subprocess.Popen("python main.py",
                           shell=True,
                           stdout=subprocess.PIPE,
                           stdin=subprocess.PIPE,
                           stderr=subprocess.STDOUT)
player2 = subprocess.Popen("python main.py",
                           shell=True,
                           stdout=subprocess.PIPE,
                           stdin=subprocess.PIPE,
                           stderr=subprocess.STDOUT)

# main - test behaviour
board = np.zeros((6, 7), dtype=np.int)
player1.stdin.write(start_string(1))
player2.stdin.write(start_string(2))

i_round = 1
t_move = 1000

for i_round in range(1, 21):
    # player1 plays
    move = player_play(1, i_round, board, t_move).rstrip()
    board = board_update(board, move, 1)
    plt.imshow(board, interpolation="nearest")
    plt.show(block=False)
    plt.pause(0.5)
    if dhw.did_he_win(board, 1):
        print "player 1 win"
        break
    else:
        # player2 plays
        move = player_play(2, i_round, board, t_move)
        board = board_update(board, move, 2)
        plt.imshow(board, interpolation="nearest")
        plt.show(block=False)
        plt.pause(0.5)
        if dhw.did_he_win(board, 2):
            print "player 2 win"
            break

print("round %i" % i_round)
player1.kill()
player2.kill()
plt.ioff()
plt.show()
